const todos = [
  {
    text: 'Order cat food',
    completed: false
  },
  {
    text: 'Clean kitchen',
    completed: true
  },
  {
    text: 'Buy food',
    completed: true
  },
  {
    text: 'Do work',
    completed: false
  },
  {
    text: 'Exercise',
    completed: true
  }
];

const filters = {
  searchText: ''
};

//seartch
const renderTodos = function(todos, filters) {
  const filteredTodos = todos.filter(function(todo) {
    return todo.text.toLowerCase().includes(filters.searchText.toLowerCase());
  });

  //incomplete todo
  const incompleteTodos = filteredTodos.filter(function(todo) {
    return !todo.completed;
  });

  //render todo each time
  document.querySelector('#todos').innerHTML = '';

  //incomplete todo list
  const summary = document.createElement('h2');
  summary.textContent = `You have ${incompleteTodos.length} todos left`;
  document.querySelector('#todos').appendChild(summary);

  //filtering filterd search and appending to new element
  filteredTodos.forEach(function(todo) {
    const p = document.createElement('p');
    p.textContent = todo.text;
    document.querySelector('#todos').appendChild(p);
  });
};

//get new vale all time
renderTodos(todos, filters);

// Listen for new todo creation
document.querySelector('#add-todo').addEventListener('click', function(e) {
  console.log('Add a new todo...');
});

// Listen for todo text change
document.querySelector('#input-filed').addEventListener('input', function(e) {
  console.log(e.target.value);
});

//search text event listner
document.querySelector('#searchtext').addEventListener('input', function(e) {
  filters.searchText = e.target.value;
  renderTodos(todos, filters);
});
